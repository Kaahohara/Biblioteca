<?php
	$servidor = "localhost";
	$usuario = "root";
	$senha = "Oieee_1234";
	$dbname = "EnergiaSolar";
	
	//Criar a conexão
	$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);
?>