<?php
function build_table($result){
    if(mysqli_num_rows($result) > 0){
        echo "<table class='tbl'>";
        echo "<tr>";
        echo "<th>Username</th>";
        echo "<th>User type</th>";
        echo "<th>Status</th>";
        echo "<th>Created by</th>";
        echo "<th>Change Status</th>";
        echo "<th>Actions</th>";
        echo "</tr><br>";
        while($row = mysqli_fetch_array($result)){
        echo "<tr>";
        echo "<td>" . $row['username'] . "</td>";
        echo "<td>" . $row['usertype'] . "</td>";
        echo "<td>" . $row['status'] . "</td>";
        echo "<td>" . $row['createdby'] . "</td>";
        echo "<td>";
        echo "<a data-toggle='modal' id='up_modal' href = '#myModal' data-username = '". $row['username'] . "'>Activate </a>";
         }}} ?><div class="modal fade" id="myModal" role="dialog">
  <div class="modal-dialog modal-sm">
      <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Activate Account</h4>
      </div>
      <div class="modal-body">
          <div id="showcal"></div>
       </div>
      </div>
    </div>
  </div>
</div>
<script>
$(document).ready(function(){
    $('#myModal').on('shown.bs.modal', function () {
       var username = $("#up_modal").attr('data-username')
           $.ajax({
                type: 'GET',
                url:'activate-account.php?username='+username,
                success:function(data){
                    $('#showcal').html(data);
                }
         });
     });
 });
 </script>