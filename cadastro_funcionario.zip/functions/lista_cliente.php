<?php   
session_start();
include("conexão.php");

$id = $_GET['CPF_pessoa'];

$sql = mysqli_query($con,"SELECT Pessoa.Nome, Pessoa.Telefone, Cliente.Rua, Cliente.Numero, Cliente.Bairro, Cliente.Cidade from Pessoa, Cliente WHERE Cliente.CPF_pessoa AND Pessoa.CPF_Pessoa = $id");

while($dados = $sql->fetch_assoc()){
  
  $nome = $dados['Nome'];
  $telefone = $dados['Telefone'];
  $rua = $dados['Rua'];
  $numero = $dados['Numero'];
  $bairro = $dados['Bairro'];
  $cidade = $dados['Cidade'];

  }

?>