drop database EnergiaSolar;
create database EnergiaSolar;
use EnergiaSolar
create table Pessoa(
	CPF_pessoa VARCHAR(15) unique NOT NULL PRIMARY KEY ,
					 RG VARCHAR(15) ,
					 Telefone VARCHAR(15) NOT NULL,
					 Nome VARCHAR(50) NOT NULL, 
                     Email Varchar(50),
				     Usuários VARCHAR(20) NOT NULL);

create table Orcamento(ID_orc INT AUTO_INCREMENT PRIMARY KEY,
	Material VARCHAR(300) , 
	CPF_pessoa VARCHAR(15) REFERENCES Pessoa(CPF_pessoa),
	Custo_do_projeto varchar(300),
	Forma_de_pag VARCHAR(10),
	Parcelas INT,
	Tempo_estipulado INT,
	Transporte VARCHAR(30),
	Alimentação VARCHAR(20),
	Materiais_add VARCHAR(20));
create table Cliente(ID_Cliente INT AUTO_INCREMENT PRIMARY KEY,
	CPF_cliente VARCHAR(15) REFERENCES Pessoa(CPF_pessoa),
	CEP INT,
	Contrato VARCHAR(50) ,
	Rua VARCHAR(30) NOT NULL,           
    Cidade VARCHAR(30) NOT NULL, 
	Numero INT NOT NULL,
    Bairro VARCHAR(30) NOT NULL,
    Estado VARCHAR(30) NOT NULL,
    Vendedor VARCHAR(50) NOT NULL, 
    Obs VARCHAR(100),
	Tipo_de_telhado VARCHAR(100),
    Folha_de_levantamento VARCHAR(300), 
	ID_Fornecedor INT REFERENCES Fornecedor(ID_Fornecedor),
	Modo_de_pagamento VARCHAR(400),
    Folha_de_vistoria VARCHAR(300), Situacao VARCHAR(200)   
				 );
create table UCGD(ID_ale INT  AUTO_INCREMENT PRIMARY KEY,
    CPF_pessoa VARCHAR(25) REFERENCES Pessoa(CPF_pessoa),
	UC_GD VARCHAR(100) NOT NULL, 
	Conta_de_energia VARCHAR(100)
				     );
create table Fornecedor(ID_Fornecedor INT AUTO_INCREMENT  PRIMARY KEY,Nome_fornecedor VARCHAR(30));
create table Secretaria(ID_Secretaria  INT  AUTO_INCREMENT PRIMARY KEY,
CPF_Secretaria VARCHAR(15) REFERENCES Pessoa(CPF_pessoa),
Email VARCHAR(50),
Senha VARCHAR(40));
create table ADM(ID_ADM INT AUTO_INCREMENT PRIMARY KEY,
CPF_ADM VARCHAR(15) REFERENCES Pessoa(CPF_pessoa),
Email VARCHAR(60),
Senha VARCHAR(60));
create table Vendedor(ID_Vendedor INT AUTO_INCREMENT PRIMARY KEY,
CPF_Vendedor VARCHAR(15) REFERENCES Pessoa(CPF_pessoa),
Email VARCHAR(50),
Senha VARCHAR(40));
create table Gerente_comercial(ID_Gerente_comercial INT AUTO_INCREMENT PRIMARY KEY,
CPF_Gerente_comercial VARCHAR(15) REFERENCES Pessoa(CPF_pessoa),
Email VARCHAR(50),
Senha VARCHAR(40));
create table Gerente_vendas(ID_Gerente_vendas INT AUTO_INCREMENT PRIMARY KEY,
CPF_Gerente_vendas VARCHAR(15) REFERENCES Pessoa(CPF_pessoa),
Email VARCHAR(50),
Senha VARCHAR(40));

create table Itens(ID_Itens INT  AUTO_INCREMENT  PRIMARY KEY,
CPF_pessoa VARCHAR(15) REFERENCES Pessoa(CPF_pessoa),
ID_Fornecedor INT REFERENCES Fornecedor(ID_Fornecedor),
Potencia VARCHAR(50),
Marca VARCHAR(40),
Tipo VARCHAR(40),
Quantidade INT);

	create table Estoque(ID_Produtos INT  AUTO_INCREMENT  PRIMARY KEY,
Tipo_material VARCHAR(15) ,
Nome_fornecedor VARCHAR(30) REFERENCES Fornecedor(Nome_fornecedor),
Adicional VARCHAR(50),
Quantidade INT);

					